ecmblib
=======

**ecmblib** This is the library you can use for your project to build *.ecmb - files, while not caring about the internals of the file-format.